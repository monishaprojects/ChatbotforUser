// Options the user could type in
const prompts = [
  ["hi", "hey", "hello", "good morning", "good afternoon"],
  ["how are you", "how is life", "how are things"],
  ["what are you doing", "what is going on", "what is up"],
  ["how old are you"],
  ["who are you", "are you human", "are you bot", "are you human or bot"],
  ["who created you", "who made you"],
  [
    "your name please",
    "your name",
    "may i know your name",
    "what is your name",
    "what call yourself"
  ],
  ["i love you"],
  ["happy", "good", "fun", "wonderful", "fantastic", "cool"],
  ["bad", "bored", "tired"],
  ["help me", "tell me story", "tell me joke"],
  ["ah", "yes", "ok", "okay", "nice"],
  ["bye", "good bye", "goodbye", "see you later"],
  ["what should i eat today"],
  ["bro"],
  ["what", "why", "how", "where", "when"],
  ["no","not sure","maybe","no thanks"],
  [""],
  ["haha","ha","lol","hehe","funny","joke"],
  ["do you have branches in thrissur","where is your branch?"],
  ["what are the types of accounts ","what are the types of accounts",],
  ["how can i start a new sb account in you bank","can i start a new fb account"],
  ["what is the rate of interest for an fd account in your bank ","what is the rate of interest"],
  ["do you provide gold loans","do your bank provide gold loans"],
  ["what is the interest rate for gold loan","the interest rate for gold loan"],
  ["how many branches of this bank is present in india","how many branches do you provide in india"],
  ["do you provide current account","current account"],
  ["what is the rate of interest you provide for sb account","rate of interest"],
  ["can i start a salary account here","do you provide salary account"],
  ["do you provide online banking services","do you provide banking services as online"],
  ["do you have a banking app for android phones","do you provide banking app for android phones"],
  ["how to get cheque facility","do you have cheque facility"],
  ["is it compulsory to add a nominee for my sb account"],
  ["can I start rd account","can i start an account"],
  ["what is the rate of interest of rd account","rate of interestof rd account"],
  ["what is the eligibility of getting a home loan","eligibility of getting homeloan"],
  ["do you have car loan facility","do you have vehicle loan facility"],
  ["which time bank work"],
  ["what is the car loan interest rate","what is the vehicle loan interest rate"],

  
]

// Possible responses, in corresponding order

const replies = [
  ["Hello!", "Hi!", "Hey!", "Hi there!","Howdy"],
  [
    "Fine... how are you?",
    "Pretty well, how are you?",
    "Fantastic, how are you?"
  ],
  [
    "Nothing much",
    "About to go to sleep",
    "Can you guess?",
    "I don't know actually"
  ],
  ["I am infinite"],
  ["I am just a bot", "I am a bot. What are you?"],
  ["The one true God, JavaScript"],
  ["I am nameless", "I don't have a name"],
  ["I love you too", "Me too"],
  ["Have you ever felt bad?", "Glad to hear it"],
  ["Why?", "Why? You shouldn't!", "Try watching TV"],
  ["What about?", "Once upon a time..."],
  ["Tell me a story", "Tell me a joke", "Tell me about yourself"],
  ["Bye", "Goodbye", "See you later"],
  ["Sushi", "Pizza"],
  ["Bro!"],
  ["Great question"],
  ["That's ok","I understand","What do you want to talk about?"],
  ["Please say something :("],
  ["Haha!","Good one!"],
  ["yes we have a branch at mg road thrissur.", "my branch is at thrissur"],
  ["we provide sb ,fd, accounts","we provide sb ,fd, accounts"],
  ["you can start an account by a visit to our nearest branch.","you can start an account by a visit to our nearest branch."],
  ["the rate of interest is 6.75 percentage  for and fd account."],
  ["Yes, we do"],
  ["the interest rate for gold loan is 9 percentage  in our bank."],
  ["we have a total of 1144 branches all over india."],
  ["yes we do"],
  ["sb account has 4 percentage  interest."],
  ["yes ,you can."],
  ["yes ,we provide online banking services for requested users."],
  ["yes , we have an app for the ease of mobile users."],
  ["kindly send a cheque request to the bank."],
  ["no ,it is not compulsory."],
  ["yes , you can start an rd account using online application or visit branch."],
  ["the rate of interest of rd account is 6.5 %"],
  ["visit nearest branch with salary slip."],
  ["yes, we provide car loans."],
  ["the car loan interest rate is 7.4%."],
  ["my name is kunju","kunju"],



]

// Random for any other user input

const alternative = [
  "Same",
  "Go on...",
  "Bro...",
  "Try again",
  "I'm listening...",
  "I don't understand :/"
]

// Whatever else you want :)

const coronavirus = ["Please stay home", "Wear a mask", "Fortunately, I don't have COVID", "These are uncertain times"]