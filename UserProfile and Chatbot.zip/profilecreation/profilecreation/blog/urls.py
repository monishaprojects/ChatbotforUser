from django.urls import path
from . import views
urlpatterns=[
	
	path('',views.home,name='home'),
	path('register',views.register,name='register'),
	path('login',views.login,name='login'),
	path('logout',views.logout_x,name='logout'),
	path('profile',views.profile,name='profile'),
	path('pm',views.pm,name='pm'),
	path('chat',views.chat,name='chat'),
	path('upload',views.adding, name='upload'),
	path('edit/<int:pk>/',views.editing,name='edit'),
	path('delete/<int:pk>/',views.delete,name='delete'),
]