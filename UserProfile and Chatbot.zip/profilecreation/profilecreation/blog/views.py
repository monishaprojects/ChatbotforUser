from django.shortcuts import render,redirect,get_object_or_404
from . models import UserProfile
from django.contrib.auth.models import User,auth
from django.contrib import messages
from . models import *
from django.contrib.auth import authenticate , login ,logout
from . forms import *
from django.contrib.auth import logout
# Create your views here.



def home(request):
	return render(request,'index.html')
def register(request):
	if request.method=='POST':
		fn=request.POST['name']
		em=request.POST['email']
		un=request.POST['username']
		psw1=request.POST['password1']
		psw2=request.POST['password2']

		if psw1==psw2:
			if User.objects.filter(username=un).exists():
				messages.warning(request,'username already exist sorry try again')
				return redirect('register')
			else:
				usr=User.objects.create_user(email=em,username=un,password=psw1)	
				usr.save()
				return redirect('/')
		else:
			messages.warning(request,'not matching password')		

	return render(request,'signup.html')



def login(request):
	if request.method=='POST':
		u=request.POST['username']
		p=request.POST['password']
		ur=auth.authenticate(username=u,password=p)
		if ur is not None:
			auth.login(request,ur)
			return redirect('/upload',{'x':u})
		else:
			
			messages.info(request, 'invalid username or password')
			return redirect('login')
	else:		
		return render(request,'login.html')
	return render(request,'login.html')



def profile(request):
	a=UserProfile.objects.all()
	return render(request,'profile.html',{'data':a})

def pm(request):
	return render(request,'profilemanagement.html')

def chat(request):
	return render(request,'chat.html')

def adding(request):
	a=ads(request.POST or None)
	if a.is_valid():
		a.save()
		return redirect('/profile')
	return render(request,'upload_profile.html',{'y':a})



def editing(request,pk):
	edt=get_object_or_404(UserProfile,pk=pk)
	a=ads(request.POST or None,instance=edt)
	if a.is_valid():
		a.save()
		return redirect('/profile')
	return render(request,'profilemanagement.html',{'y':a})

def delete(request,pk):
	dele=get_object_or_404(UserProfile,pk=pk)
	if request.method=='POST':
		dele.delete()
		dele.delete()
		return redirect('/profile')
	return render(request,'profilemanagement.html',{'y':dele})


def logout_x(request):
	logout(request)
	messages.info(request, "Logged out successfully!")	
	return render(request,'index.html')
	